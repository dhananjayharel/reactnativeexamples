import api from './api';

export { api };
