import loggerMiddleware from './logger';

export {
  loggerMiddleware,
};
