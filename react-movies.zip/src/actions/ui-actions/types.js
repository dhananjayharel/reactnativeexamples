export const UI_CHANGE_THEME = '[UI] CHANGE_THEME';
