const Colors = {
  red: '#FC0303',
  white: '#FFFFFF',
  black: '#050405',
  green: '#01D475',
  lightGrey: '#9A9A9A',
  darkGrey: '#282828',
};

export default Colors;
