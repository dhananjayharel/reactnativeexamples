export const YOUTUBE_URL = 'YOUTUBE_URL';
export const THEMOVIEDB_API_KEY = '0864be8a90798694e64b7fa776169342';
export const THEMOVIEDB_RESOURCE_URL = 'https://api.themoviedb.org/3';