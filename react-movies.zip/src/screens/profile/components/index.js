import MenuConfigItem from './menu-config-item';

export { MenuConfigItem };
