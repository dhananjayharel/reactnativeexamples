import useFetch from './use-fetch';
import useRemoteConfig from './use-remote-config';

export {
  useFetch,
  useRemoteConfig,
};
